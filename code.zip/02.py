import pandas as pd
import os
import multiprocessing
from glob import glob


def csv_to_shp(csv_file):
    df = pd.read_csv(csv_file)
    df['time'] = pd.to_datetime(df['time'])
    filename = csv_file.replace('02csv格式', '04csv时间')
    df.to_csv(filename)
    print(f"转换完成: {csv_file} 到 {filename}")


def process_file(csv_file):
    csv_to_shp(csv_file)


def main():
    csv_files = glob(r"F:\project\cml毕设相关\08腾讯位置相关\01data\02csv格式\*.csv")
    with multiprocessing.Pool(processes=20) as pool:
        pool.map(process_file, csv_files)


if __name__ == "__main__":
    main()
