# 这个代码是一坨屎，希望你不会有机会用到它
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans, AgglomerativeClustering, DBSCAN, SpectralClustering
from sklearn.metrics import davies_bouldin_score
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn.cluster import KMeans
from sklearn.metrics import davies_bouldin_score
from sklearn.preprocessing import StandardScaler
from tslearn.clustering import TimeSeriesKMeans
from tslearn.preprocessing import TimeSeriesScalerMeanVariance
import geopandas as gpd

csv_file = 'test365_5km_hours_0_10_10.csv'
df = pd.read_csv(f"F:/project/cml毕设相关/08腾讯位置相关/01data/06其他处理/筛选时间序列/{csv_file}", index_col=0)

# 标准化时间序列数据
scaler = TimeSeriesScalerMeanVariance(mu=0., std=1.)  # Z-normalize time series
df_scaled = scaler.fit_transform(df.T.values.reshape(df.shape[1], df.shape[0]))

# 使用 DTW 进行聚类
# 类别个数设定
n = 4
model = TimeSeriesKMeans(n_clusters=n, metric="dtw", verbose=True, random_state=818, n_jobs=10)
labels = model.fit_predict(df_scaled)

# 计算 Davies-Bouldin Index
dbi = davies_bouldin_score(df_scaled.squeeze(), labels)
print('Davies-Bouldin Index:', dbi)

# 计算每个簇的平均时间序列
cluster_averages = pd.DataFrame(df_scaled.squeeze()).groupby(labels).mean()

# 绘制每个类别的平均时间序列
plt.figure(figsize=(14, 7))
for cluster_label in np.unique(labels):
    plt.plot(cluster_averages.loc[cluster_label], label=f'Cluster {cluster_label}')
plt.title('Average Time Series for Each Cluster')
plt.xlabel('Hour of the day')
plt.xticks(ticks=np.arange(24), labels=[f'{hour}:00' for hour in range(24)])
plt.ylabel('Value')
plt.legend()
# plt.show()
add = f"F:/project/cml毕设相关/01论文稿/02图/02腾讯位置相关图/聚类图/日内/{csv_file[:-3]}_dtw.jpg"
plt.savefig(add, dpi=500)

unique_labels, counts = np.unique(labels, return_counts=True)
print(unique_labels, counts)
result_df = pd.DataFrame({
    'FID': df.T.index,
    'cluster': labels
})

file_path = r"F:\project\cml毕设相关\08腾讯位置相关\01data\06其他处理\原始格网数据_用于筛选\原始缓冲区.shp"
gdf = gpd.read_file(file_path)

merged_gdf = gdf.merge(result_df, left_on='OID_', right_on='FID', how='inner')

output_shp_path = f"F:/project/cml毕设相关/08腾讯位置相关/01data/06其他处理/筛选数据/{csv_file[:-3]}_dtw.shp"
merged_gdf.to_file(output_shp_path)
