import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans, AgglomerativeClustering, DBSCAN, SpectralClustering
from sklearn.metrics import davies_bouldin_score
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from tslearn.clustering import TimeSeriesKMeans
from tslearn.preprocessing import TimeSeriesScalerMeanVariance
from scipy.spatial.distance import pdist, squareform
from scipy.cluster.hierarchy import dendrogram, linkage
from tslearn.metrics import dtw
from scipy.cluster.hierarchy import fcluster
import geopandas as gpd
# 忽略警告
from sklearn.metrics import silhouette_score
import warnings

warnings.filterwarnings('ignore')


def dtw_distance(series1, series2):
    return dtw(series1.reshape(-1, 1), series2.reshape(-1, 1))


def record_clustering_info(csv_filename, clustering_height, silhouette_score, record_file='F:/project/cml毕设相关/08'
                                                                                          '腾讯位置相关/01data/06其他处理/聚类记录.csv'):
    """
    记录聚类信息到 CSV 文件

    :param csv_filename: 用于聚类的 CSV 文件名
    :param clustering_height: 聚类树的切割高度
    :param silhouette_score: 轮廓系数
    :param record_file: 保存记录的 CSV 文件路径
    """
    # 创建一个包含信息的 DataFrame
    record_df = pd.DataFrame({
        'CSV Filename': [csv_filename],
        'Clustering Height': [clustering_height],
        'Silhouette Score': [silhouette_score]
    })

    # 检查文件是否存在，如果不存在，创建文件并写入表头
    if not os.path.isfile(record_file):
        record_df.to_csv(record_file, index=False, mode='w')
    else:
        # 如果文件存在，追加数据
        record_df.to_csv(record_file, index=False, mode='a', header=False)


csv_file = 'test365_5km_hours_0_10_10.csv'
df = pd.read_csv(f"F:/project/cml毕设相关/08腾讯位置相关/01data/06其他处理/筛选时间序列/{csv_file}", index_col=0)

scaler = TimeSeriesScalerMeanVariance(mu=0., std=1.)  # Z-normalize time series
df_scaled = scaler.fit_transform(df.T.values.reshape(df.shape[1], df.shape[0], 1))

dist_matrix = pdist(df_scaled.squeeze(), metric=dtw_distance)

Z = linkage(dist_matrix, method='ward')
plt.figure(figsize=(20, 7))
dendrogram(Z);
plt.title('Average Time Series for Each Cluster')
# plt.xlabel('Time Index')
plt.ylabel('Height')
# plt.legend()
plt.savefig(f"F:/project/cml毕设相关/01论文稿/02图/02腾讯位置相关图/聚类图/系谱图/{csv_file[:-4]}_dendrogram.png", dpi=600)

# 高度设定
height = 35

# 使用 fcluster 函数根据高度切割树状图
labels = fcluster(Z, height, criterion='distance')

silhouette_score_value = silhouette_score(df_scaled.squeeze(), labels)
print(f"轮廓系数：{silhouette_score_value}")
record_clustering_info(csv_file, height, silhouette_score_value)

# 计算每个类的平均时间序列
df_scaled_squeezed = df_scaled.squeeze()
cluster_averages = pd.DataFrame(df_scaled_squeezed).groupby(labels).mean()

# 为每个聚类的平均时间序列重命名列，并进行转置
all_clusters_df = cluster_averages.T
all_clusters_df.columns = [f'Cluster_{cluster_label}' for cluster_label in np.unique(labels)]

# 保存所有聚类的时间序列到一个 CSV 文件
all_clusters_csv_path = f"F:/project/cml毕设相关/01论文稿/02图/02腾讯位置相关图/聚类图/{csv_file[:-4]}_all_clusters.csv"
all_clusters_df.to_csv(all_clusters_csv_path)

all_clusters_csv_path = f"F:/project/cml毕设相关/01论文稿/02图/02腾讯位置相关图/聚类图/日内表/{csv_file[:-4]}_dendrogram{height}.csv"
all_clusters_df.to_csv(all_clusters_csv_path, index=False)

# 绘制每个类别的平均时间序列
plt.figure(figsize=(14, 7))
for cluster_label in np.unique(labels):
    plt.plot(cluster_averages.loc[cluster_label], label=f'Cluster {cluster_label}')
plt.title('Average Time Series for Each Cluster')
plt.xlabel('Hour of the day')
plt.xticks(ticks=np.arange(24), labels=[f'{hour}:00' for hour in range(24)])
plt.ylabel('Value')
plt.legend()
plt.savefig(f"F:/project/cml毕设相关/01论文稿/02图/02腾讯位置相关图/聚类图/日内/{csv_file[:-4]}_dendrogram{height}.png", dpi=600)

df_col_names = pd.DataFrame(df.columns, columns=['LOCATION'])

# 创建一个包含 labels 数组的 DataFrame
labels_df = pd.DataFrame(labels, columns=['clusterid'])

# 拼接两个 DataFrame
result_df = pd.concat([df_col_names, labels_df], axis=1)
result_df['LOCATION'] = result_df['LOCATION'].astype('int64')
# 查看结果

file_path = r"F:\project\cml毕设相关\08腾讯位置相关\01data\06其他处理\原始格网数据_用于筛选\test365_5km.shp"
gdf = gpd.read_file(file_path)
merged_gdf = gdf.merge(result_df, left_on='LOCATION', right_on='LOCATION', how='inner')

output_shp_path = f"F:/project/cml毕设相关/08腾讯位置相关/01data/06其他处理/筛选数据/{csv_file[:-4]}_dendrogram{height}.shp"
merged_gdf.to_file(output_shp_path)
