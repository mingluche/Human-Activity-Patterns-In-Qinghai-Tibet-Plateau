import geopandas as gpd

# 文件路径
path = "F:/project/cml毕设相关/08腾讯位置相关/03工程目录/test.gdb"
polygon_path = "test1"
point_path = "test2"

# 读取数据

points = gpd.read_file(path, layer=point_path)
polygons = gpd.read_file(path, layer=polygon_path)
print(type(polygons))
print(type(points))
# 计算交集
# intersection = gpd.overlay(points, polygons, how='intersection')
intersection = gpd.sjoin(points, polygons)
# 保存结果到Geodatabase
output_path = r"F:\project\cml毕设相关\08腾讯位置相关\03工程目录\test.gdb"
output_layer = "outtest1"
intersection.to_file(path, layer=output_layer, driver="FileGDB")
