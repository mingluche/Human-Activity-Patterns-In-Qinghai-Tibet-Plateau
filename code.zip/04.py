# 这个代码是一坨屎，希望你不会有机会用到它
import pandas as pd
import numpy as np
import netCDF4 as nc
import os


def print_nc_file_structure(nc_file):
    """
    打印NetCDF文件的结构。

    参数:
    nc_file (str): NetCDF文件的路径。
    """
    # 打开NetCDF文件
    dataset = nc.Dataset(nc_file, 'r')

    print("\n维度:")
    for dim in dataset.dimensions.values():
        print(f"  {dim.name} = {len(dim)}")

    print("\n变量:")
    for var in dataset.variables.values():
        print(f"  {var.name}:")
        for attr in var.ncattrs():
            print(f"    {attr} = {getattr(var, attr)}")
        print("\n\n\n")

    # 关闭文件
    dataset.close()


os.chdir(r"F:\project\cml毕设相关\08腾讯位置相关\01data\06其他处理\时空立方体")
ncfile = "test365_5km_hours.nc"
dataset = nc.Dataset(ncfile)

# 打印NetCDF文件的结构
# print_nc_file_structure(ncfile)
# print(dataset.variables.keys())

nplat = np.array(dataset.variables["lat"])
nplon = np.array(dataset.variables["lon"])
npcount = np.array(dataset.variables["NUM_SUM_ZEROS"])
# npoid = np.array(dataset.variables["OID_"])  # 如果是分区聚类，可以启用这个变量
nplocationID = np.array(dataset.variables["location_ID"])
nptime = np.array(dataset.variables["time"])
print(nplocationID.shape)
print(f"lat.shape:{nplat.shape}")
print(f"lon.shape:{nplon.shape}")
print(f"nptime.shape[0]:{nptime.shape[0]}")
print(f"npcount.shape:{npcount.shape}")

data = []
IDlist = []
# 筛选出有效数据
a = 0  # 绝对中位差
b = 100  # 最小值
c = 500  # 中位数

# 缓冲区筛选
# for y in range(len(nplon)):
#     if npcount[1, y] != -9999.0:
#         nmedian = np.median(npcount[:, y])
#         nmad = np.median(np.abs(npcount[:, y] - nmedian))
#         nmin = np.min(npcount[:, y])
#         if nmad > a and nmin >= b and nmedian >= c:
#             IDlist.append(npoid[1, y])
#             data.append(npcount[:, y])
#         # 每一个IDlist的24行数据 = npcount[:,y,x]
#     else:
#         continue

# 格网筛选
for y in range(len(nplon)):
    for x in range(len(nplon[y])):
        if npcount[1, y, x] != -9999.0:
            nmedian = np.median(npcount[:, y, x])
            nmad = np.median(np.abs(npcount[:, y, x] - nmedian))
            nmin = np.min(npcount[:, y, x])
            if nmad >= a and nmin >= b and nmedian >= c:
                IDlist.append(nplocationID[1, y, x])
                data.append(npcount[:, y, x])
            # 每一个IDlist的24行数据 = npcount[:,y,x]
        else:
            continue
print(f"有效数据个数:{len(IDlist)}")

# 构建时间序列
df = pd.DataFrame(index=range(nptime.shape[0]), columns=IDlist)
for col, col_data in zip(df.columns, data):
    df[col] = col_data

df.to_csv(f"F:/project/cml毕设相关/08腾讯位置相关/01data/06其他处理/筛选时间序列/{ncfile[:-3]}_{a}_{b}_{c}.csv")
