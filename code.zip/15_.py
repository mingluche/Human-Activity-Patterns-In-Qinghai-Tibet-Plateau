from cml_module import *


def main(csv_file, num_clusters):
    df = pd.read_csv(f"F:/project/cml毕设相关/08腾讯位置相关/01data/06其他处理/筛选时间序列/{csv_file}.csv",
                     index_col=0)
    features = calculate_features_year(df)
    # 聚类
    labels, centers = perform_clustering_keans(features, n_clusters=num_clusters)

    # 归一化
    scaler = TimeSeriesScalerMeanVariance(mu=0., std=1.)
    df_reshape = df.T.values.reshape(df.shape[1], df.shape[0], 1)
    df_scaled = scaler.fit_transform(df_reshape)

    # 归一化结果与未归一化结果
    cluster_averages = pd.DataFrame(df_scaled.squeeze()).groupby(labels).mean()
    cluster_mean_averages = pd.DataFrame(df_reshape.squeeze()).groupby(labels).mean()

    # 计算轮廓系数&保存分类结果
    sil_score = save_cluster_results(df_scaled, labels, num_clusters, csv_file, 'kf', clusterclass='年')
    save_cluster_img(cluster_averages, labels, num_clusters, csv_file, 'kf', clusterclass='年')
    save_cluster_results(df_reshape, labels, num_clusters, csv_file, 'kf', mean=True)
    save_cluster_img(cluster_mean_averages, labels, num_clusters, csv_file, 'kf', mean=True, clusterclass='年')

    # 链接shp
    save_geo_data(df, labels, csv_file, num_clusters, 'kf', clusterclass='年')

    # 写入记录
    record_clustering_info(csv_file, num_clusters, 'kf', sil_score, record_file='F:/project/cml毕设相关/08腾讯位置相关/01data'
                                                                                '/06其他处理/聚类记录年.csv')


if __name__ == '__main__':
    for csv_file in ['test1_5km_days_0_1_0_trend7', 'test1_5km_days_0_1_0_trend14',
                     'test1_5km_days_0_1_0_trend30']:
        for num_clusters in range(2, 10):
            print(f'当前文件{csv_file},类别数{num_clusters}')
            main(csv_file, num_clusters)
