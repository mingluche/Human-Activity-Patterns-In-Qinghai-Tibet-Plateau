import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
from tslearn.preprocessing import TimeSeriesScalerMeanVariance
from tslearn.metrics import dtw
from scipy.spatial.distance import pdist
from scipy.cluster.hierarchy import dendrogram, linkage, fcluster
from sklearn.metrics import silhouette_score
import geopandas as gpd
import warnings

warnings.filterwarnings('ignore')


def dtw_distance(series1, series2):
    """
    计算两个时间序列之间的 DTW 距离。
    """
    return dtw(series1.reshape(-1, 1), series2.reshape(-1, 1))


def perform_clustering(df, method='ward'):
    """
    执行时间序列数据的层次聚类并绘制树状图。
    """
    scaler = TimeSeriesScalerMeanVariance(mu=0., std=1.)
    df_scaled = scaler.fit_transform(df)
    dist_matrix = pdist(df_scaled.squeeze(), metric=dtw_distance)
    Z = linkage(dist_matrix, method=method)
    return df_scaled, Z


def plot_dendrogram(Z, csv_file):
    """
    绘制树状图并保存为图片。
    """
    plt.figure(figsize=(20, 7))
    dendrogram(Z)
    plt.title('Average Time Series for Each Cluster')
    plt.ylabel('Height')
    plt.savefig(f"F:/project/cml毕设相关/01论文稿/02图/02腾讯位置相关图/聚类图/系谱图/{csv_file}_dendrogram_dtw.png",
                dpi=600)
    plt.close()


def save_cluster_results(df_scaled, Z, num_clusters, csv_file, mean=False):
    """
    保存聚类结果和所有聚类的时间序列到 CSV 文件。
    """
    labels = fcluster(Z, num_clusters, criterion='maxclust')
    silhouette_score_value = silhouette_score(df_scaled.squeeze(), labels)
    print(f"轮廓系数：{silhouette_score_value}") if not mean else None
    cluster_averages = pd.DataFrame(df_scaled.squeeze()).groupby(labels).mean()
    # 为每个聚类的平均时间序列重命名列，并进行转置
    all_clusters_df = cluster_averages.T
    all_clusters_df.columns = [f'Cluster_{cluster_label}' for cluster_label in np.unique(labels)]

    # 保存所有聚类的时间序列到一个 CSV 文件
    if mean:
        all_clusters_csv_path = f"F:/project/cml毕设相关/01论文稿/02图/02腾讯位置相关图/聚类图/日内表/{csv_file}_{num_clusters}class_dtw_mean.csv"
    else:
        all_clusters_csv_path = f"F:/project/cml毕设相关/01论文稿/02图/02腾讯位置相关图/聚类图/日内表/{csv_file}_{num_clusters}class_dtw.csv"
    all_clusters_df.to_csv(all_clusters_csv_path)
    return silhouette_score_value


def save_cluster_img(df, labels, csv_file, mean=False):
    """
    保存聚类结果和所有聚类的时间序列到 png文件。
    """
    plt.figure(figsize=(14, 7))
    for cluster_label in np.unique(labels):
        plt.plot(df.loc[cluster_label], label=f'Cluster {cluster_label}')
    plt.title('Average Time Series for Each Cluster')
    plt.xlabel('Hour of the day')
    plt.xticks(ticks=np.arange(24), labels=[f'{hour}:00' for hour in range(24)])
    plt.ylabel('Value')
    plt.legend()
    if mean:
        plt.savefig(
            f"F:/project/cml毕设相关/01论文稿/02图/02腾讯位置相关图/聚类图/日内平均/{csv_file}_{num_clusters}class_mean_dtw.png",
            dpi=600)
    else:
        plt.savefig(
            f"F:/project/cml毕设相关/01论文稿/02图/02腾讯位置相关图/聚类图/日内/{csv_file}_{num_clusters}class_dtw.png",
            dpi=600)
    plt.close()


def save_geo_data(df, labels, csv_file):
    """
    保存聚类结果和所有聚类的时间序列到 shp 文件。
    """
    # 合并时间序列聚类结果与地理数据并保存
    df_col_names = pd.DataFrame(df.columns, columns=['LOCATION'])
    labels_df = pd.DataFrame(labels, columns=['clusterid'])
    result_df = pd.concat([df_col_names, labels_df], axis=1)
    result_df['LOCATION'] = result_df['LOCATION'].astype('int64')

    file_path = r"F:\project\cml毕设相关\08腾讯位置相关\01data/06其他处理/原始格网数据_用于筛选\test365_5km.shp"
    gdf = gpd.read_file(file_path)
    merged_gdf = gdf.merge(result_df, left_on='LOCATION', right_on='LOCATION', how='inner')

    output_shp_path = f"F:/project/cml毕设相关/08腾讯位置相关/01data/06其他处理/筛选数据/{csv_file}_{num_clusters}class_dtw.shp"
    merged_gdf.to_file(output_shp_path)


def record_clustering_info(csv_filename, num_clusters, method, silhouette_score,
                           record_file='F:/project/cml毕设相关/08腾讯位置相关/01data/06其他处理/聚类记录2.csv'):
    """
    记录聚类信息到 CSV 文件

    :param csv_filename: 用于聚类的 CSV 文件名
    :param num_clusters: 聚类数量
    :param silhouette_score: 轮廓系数
    :param record_file: 保存记录的 CSV 文件路径
    """
    # 创建一个包含信息的 DataFrame
    record_df = pd.DataFrame({
        'CSV Filename': [csv_filename],
        'Clustering number': [num_clusters],
        'method': [method],
        'Silhouette Score': [silhouette_score]
    })

    # 检查文件是否存在，如果不存在，创建文件并写入表头
    if not os.path.isfile(record_file):
        record_df.to_csv(record_file, index=False, mode='w')
    else:
        # 如果文件存在，读取文件
        existing_df = pd.read_csv(record_file)
        # 检查是否存在相同的记录
        if not ((existing_df['CSV Filename'] == csv_filename) &
                (existing_df['num_clusters'] == num_clusters) &
                (existing_df['method'] == method)).any():
            record_df.to_csv(record_file, index=False, mode='a', header=False)
            # 如果不存在相同记录，则追加数据
        # 如果存在相同记录，则不进行操作


def main(csv_file, num_clusters):
    """
    主函数，执行聚类分析和结果保存。
    """
    df = pd.read_csv(f"F:/project/cml毕设相关/08腾讯位置相关/01data/06其他处理/筛选时间序列/{csv_file}.csv",
                     index_col=0)
    df_reshape = df.T.values.reshape(df.shape[1], df.shape[0], 1)

    # 执行聚类并绘制树状图
    df_scaled, Z = perform_clustering(df_reshape)
    plot_dendrogram(Z, csv_file)
    # 计算每个类的平均时间序列
    labels = fcluster(Z, num_clusters, criterion='maxclust')
    cluster_averages = pd.DataFrame(df_scaled.squeeze()).groupby(labels).mean()
    cluster_mean_averages = pd.DataFrame(df_reshape.squeeze()).groupby(labels).mean()
    # 保存聚类结果和所有聚类的时间序列到 CSV 文件
    sil_score = save_cluster_results(df_scaled, Z, num_clusters, csv_file)
    save_cluster_img(cluster_averages, labels, csv_file)
    # 保存原始平均结果
    save_cluster_results(df_reshape, Z, num_clusters, csv_file, mean=True)
    save_cluster_img(cluster_mean_averages, labels, csv_file, mean=True)

    save_geo_data(df, labels, csv_file)
    # 写入记录
    record_clustering_info(csv_file, num_clusters, 'dtw', sil_score)


if __name__ == '__main__':
    csv_file = 'test365_5km_hours_0_10_10'
    num_clusters = 2
    main(csv_file, num_clusters)
