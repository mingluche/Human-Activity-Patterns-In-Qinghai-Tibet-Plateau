import pandas as pd
import numpy as np
from statsmodels.tsa.seasonal import STL
# from tslearn.preprocessing import TimeSeriesScalerMeanVariance

df = pd.read_csv(f"F:/project/cml毕设相关/08腾讯位置相关/01data/06其他处理/筛选时间序列/test1_5km_days_0_1_0.csv", index_col=0)
# scaler = TimeSeriesScalerMeanVariance(mu=0., std=1.)
# df_scaled = scaler.fit_transform(df.T)
# df_scaled = pd.DataFrame(df_scaled.reshape(df_scaled.shape[0], df_scaled.shape[1]), index=df.columns)


# Simulating a DataFrame with random values for demonstration purposes
def stl_decomposition(original_df, scaled_df, period=30):
    trend_parts = []
    for i in range(scaled_df.shape[0]):
        series = scaled_df.iloc[i, :]
        stl = STL(series, period=period, robust=True)
        result = stl.fit()
        trend_parts.append(result.trend)
    trend_df = pd.DataFrame(trend_parts, index=original_df.columns, columns=original_df.index).T
    return trend_df


# Perform STL decomposition and extract the trend component
df_trend = stl_decomposition(df, df.T, period=30)
df_trend.to_csv(f"F:/project/cml毕设相关/08腾讯位置相关/01data/06其他处理/筛选时间序列/test1_5km_days_0_1_0_trend30.csv")
print('1')
df_trend = stl_decomposition(df, df.T, period=14)
df_trend.to_csv(f"F:/project/cml毕设相关/08腾讯位置相关/01data/06其他处理/筛选时间序列/test1_5km_days_0_1_0_trend14.csv")
print('2')
df_trend = stl_decomposition(df, df.T, period=7)
df_trend.to_csv(f"F:/project/cml毕设相关/08腾讯位置相关/01data/06其他处理/筛选时间序列/test1_5km_days_0_1_0_trend7.csv")
print('3')
