import pandas as pd
import os
from glob import glob
from concurrent.futures import ThreadPoolExecutor


def process_file(file_name, out_date):
    data = []
    with open(file_name, "r") as file:
        for line in file:
            parts = line.strip().split(',')
            if len(parts) > 1 and ':' in parts[0]:
                time = parts[0]
                for i in range(1, len(parts), 3):
                    lat = float(parts[i]) / 100
                    lon = float(parts[i + 1]) / 100
                    count = parts[i + 2]
                    data.append([f"{time}", lon, lat, count])

    df = pd.DataFrame(data, columns=["time", "lon", "lat", "num"])
    df["time"] = pd.to_datetime(df["time"])
    df.sort_values(by="time", inplace=True)

    output_file = f"F:/project/cml毕设相关/08腾讯位置相关/01data/02csv格式/{out_date}.csv"
    df.to_csv(output_file, index=False, encoding='utf-8')
    print(f"文件 {file_name} 已处理并保存为 {output_file}")


def process_file_thread(file_name, out_date):
    process_file(file_name, out_date)
    print(f"处理完成: {file_name}")


def main():
    files = glob(r"F:\project\cml毕设相关\08腾讯位置相关\01data\01origin\tencent_loc_hour_filter\*\part-00000")

    with ThreadPoolExecutor(max_workers=8) as executor:
        for file in files:
            out_date = os.path.basename(os.path.dirname(file)).replace("-", "_")
            executor.submit(process_file, file, out_date)


if __name__ == "__main__":
    main()
